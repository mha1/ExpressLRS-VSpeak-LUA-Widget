--
-- VSpeak for ExpressLRS V1.14
--

-- *************************************************************************
-- ** ECU_type :  1 ... Jakadofsky                                        **
-- ** ECU_type :  2 ... evoJet                                            **
-- ** ECU_type :  3 ... PBS                                               **
-- ** ECU_type :  4 ... HORNET                                            **
-- ** ECU_type :  5 ... JetCat                                            **
-- ** ECU_type :  6 ... KingTech                                          **
-- ** ECU_type :  7 ... AMT                                               **
-- ** ECU_type :  8 ... Xicoy_Kolibri                                     **
-- ** ECU_type :  9 ... JetCentral                                        **
-- ** ECU_type : 10 ... Kolibri_NG                                        **
-- ** ECU_type : 11 ... Swiwin                                            **
-- ** ECU_type : 12 ... Linton                                            **
-- *************************************************************************

local defaultOptions = {
	{ "ECU_type", CHOICE, 6, 
		{ "Jakadofsky", 
			"evoJet ", 
			"PBS3",
			"HORNET",
			"JetCat",
			"KingTech",
			"AMT",
			"Xicoy_Kolibri",
			"JetCentral",
			"Kolibri_NG",
			"Swiwin",
			"Linton",
		}
	}
}

local function prepare(thisZone)
  thisZone.ImgRpm = Bitmap.open("/WIDGETS/Vspeak_ECU/img/rpm.png")
  thisZone.ImgEgt = Bitmap.open("/WIDGETS/Vspeak_ECU/img/tmp.png")
  thisZone.ImgBat = Bitmap.open("/WIDGETS/Vspeak_ECU/img/batt.png")
  thisZone.ImgTnk = Bitmap.open("/WIDGETS/Vspeak_ECU/img/gasoline.png")
  thisZone.ImgSpd = Bitmap.open("/WIDGETS/Vspeak_ECU/img/spd.bmp")
  thisZone.ImgVsp = Bitmap.open("/WIDGETS/Vspeak_ECU/img/logo.png")

	thisZone.speedIdx  = getSourceIndex("ASpd")		  -- speed	
	thisZone.rpmIdx 	 = getSourceIndex("RPM")+0*3	-- rpm
	thisZone.fuelIdx   = getSourceIndex("RPM")+2*3	-- fuel in ml
	thisZone.egtIdx    = getSourceIndex("Temp")+2*3	-- EGT
	thisZone.throttIdx = getSourceIndex("Temp")+5*3	-- throttle %
	thisZone.statusIdx = getSourceIndex("Temp")+6*3 -- status/alarm	
	thisZone.ecu_vIdx  = getSourceIndex("Volt")+0*3	-- ECU voltage
	thisZone.pump_vIdx = getSourceIndex("Volt")+1*3	-- pump voltage/PW
end


function create(zone, options)
	prepare(zone)
	
  return { zone			 = zone,
					 options   = options,
					 speedIdx  = zone.speedIdx,
					 rpmIdx 	 = zone.rpmIdx,
					 fuelIdx   = zone.fuelIdx,
					 egtIdx    = zone.egtIdx,
					 throttIdx = zone.throttIdx,
					 statusIdx = zone.statusIdx,
					 ecu_vIdx  = zone.ecu_vIdx,
					 pump_vIdx = zone.pump_vIdx,
					 ImgRpm 	 = zone.ImgRpm, 
					 ImgEgt 	 = zone.ImgEgt,
				 	 ImgBat 	 = zone.ImgBat,
					 ImgTnk 	 = zone.ImgTnk,
					 ImgSpd 	 = ImgSpd,
					 ImgVsp 	 = zone.ImgVsp 
				 }
end

function update(thisZone, options)
	prepare(thisZone)

  thisZone.options = options
end

function draw_status(x, y, src, turb)
	local msg_table_Jakadofsky = {
		[-30] = " ERROR",
		[-20] = "TH:-off",
		[-10] = "TH:cool",
		[-1] = "TH:lock",
		[0] = "TH:stop",
		[10] = "TH:run-",
		[20] = "TH:rel-",
		[25] = "TH:glow",
		[30] = "TH:spin",
		[40] = "TH:fire",
		[45] = "TH:ignt",
		[50] = "TH:heat",
		[60] = "TH:acce",
		[65] = "TH:cal.",
		[70] = "TH:idle",
	}
	local msg_table_evoJet = {
		[-30] = " ERROR",
		[-20] = "TH:-off",
		[-10] = "TH:cool",
		[-1] = "TH:lock",
		[0] = "TH:stop",
		[10] = "TH:run-",
		[20] = "TH:rel-",
		[25] = "TH:glow",
		[30] = "TH:spin",
		[40] = "TH:fire",
		[45] = "TH:ignt",
		[50] = "TH:heat",
		[60] = "TH:acce",
		[65] = "TH:cal.",
		[70] = "TH:idle",
	}
	local msg_table_PBS = {
		[-30] = "ERROR",
		[-10] = "COOL",
		[-1] = "LOCK",
		[0] = "STOP",
		[10] = "TH:Idle",
		[20] = "TH:-Rel",
		[25] = "TEST",
		[40] = "FIRE",
		[70] = "IDLE",
	}
	local msg_table_HORNET = {
		[-30] = "DEV.DELAY",
		[-20] = "FLAME OUT",
		[-10] = "EMERGENCY",
		[0] = "OFF",
		[1] = "ON",
		[10] = "Cool Down",
		[20] = "Slow Down",
		[30] = "STANDBY",
		[31] = "PROP IGNIT",
		[32] = "PROP HEAT",
		[33] = "Pump Start",
		[34] = "BURNER ON",
		[35] = "FUEL IGNIT",
		[36] = "FUEL HEAT",
		[37] = "Ramp Delay",
		[38] = "RAMP UP",
		[40] = "STEADY",
		[41] = "CAL IDLE",
		[42] = "CALIBRATE",
		[43] = "WAIT ACC",
		[44] = "GO IDLE",
		[50] = "AUTO",
		[51] = "AUTO HC",
	}
	local msg_table_JetCat = {
		[-40] = "Failure",
		[-32] = "ECU reboot",
		[-31] = "ClutchFail",
		[-30] = "Low Rpm",
		[-29] = "Low Rpm",
		[-28] = "Out Fuel",
		[-27] = "Pump Comm",
		[-26] = "WrongPump",
		[-25] = "No Pump!",
		[-24] = "OverCurr",
		[-23] = "No-OIL",
		[-22] = "2nd Comm",
		[-21] = "2nd Diff",
		[-20] = "2nd EngF",
		[-19] = "Rpm2Fail",
		[-18] = "FuelFail",
		[-17] = "TempFail",
		[-16] = "PowerFail",
		[-15] = "IgnTimOut",
		[-14] = "FailSafe",
		[-13] = "WatchDog",
		[-12] = "GlowPlug!",
		[-11] = "HiTempOff",
		[-10] = "LowTempOff",
		[-9] = "OverTemp",
		[-8] = "BattryLow",
		[-7] = "Low-Rpm",
		[-6] = "Over-Rpm",
		[-5] = "Acc. Slow",
		[-4] = "AccTimOut",
		[-3] = "Manual Off",
		[-2] = "Auto-Off",
		[-1] = "RC-Off",
		[0] = "-OFF-",
		[1] = "SlowDown",
		[2] = "SwitchOff",
		[3] = "Stby/START",
		[4] = "PreHeat1",
		[5] = "PreHeat2",
		[6] = "Ignite...",
		[7] = "AccelrDly",
		[8] = "MainFStrt",
		[9] = "Keros.Full",
		[10] = "accelerate",
		[11] = "Stabilise",
		[12] = "LearnLO",
		[13] = "RUN (reg.)",
		[14] = "SpeedCtrl",
		[15] = "Rpm2Ctrl",
	}
	local msg_table_KingTech = {
		[-20] = "- ERROR -",
		[-19] = "Unknown",
		[-13] = "CAB-Lost",
		[-12] = "FlameOut",
		[-11] = "TempHigh",
		[-10] = "SpeedLow",
		[-9] = "Failsafe",
		[-8] = "RxPwFail",
		[-7] = "Overload",
		[-6] = "Low Batt",
		[-5] = "StartBad",
		[-4] = "Weak Gas",
		[-3] = "Time Out",
		[-2] = "Ign.Fail",
		[-1] = "Glow Bad",
		[0] = "Trim Low",
		[1] = "User Off",
		[2] = "Stop",
		[3] = "Cooling",
		[4] = "Ready",
		[5] = "GdReady",
		[6] = "GlowTest",
		[7] = "StickLo!",
		[8] = "PrimeVap",
		[9] = "BurnerOn",
		[10] = "Start On",
		[11] = "Ignition",
		[12] = "Stage1",
		[13] = "Stage2",
		[14] = "Stage3",
		[20] = "Running",
		[22] = "ReStart",
	}
	local msg_table_AMT = {
		[-20] = "- ERROR -",
		[-8] = "Supply ASS",
		[-7] = "Supply low",
		[-6] = "RPM high",
		[-5] = "EGT error",
		[-4] = "Throttle fail",
		[-3] = "Switch failure",
		[-2] = "RPM low",
		[-1] = "No serial input",
		[0] = "No Start Clear",
		[1] = "Start Clear",
		[2] = "Starting",
		[3] = "Started up",
		[4] = "Calibrated",
		[5] = "Auto stop",
		[6] = "Running",
		[7] = "Max. RPM",
	}
	local msg_table_Xicoy_Kolibri = {
		[-14] = "FlameOut",
		[-13] = "TempHigh",
		[-12] = "SpeedLow",
		[-11] = "Failsafe",
		[-10] = "RxPwFail",
		[-9] = "PumpLimit",
		[-8] = "Overload",
		[-7] = "Low Batt",
		[-6] = "StartBad",
		[-5] = "Weak Gas",
		[-4] = "Time Out",
		[-3] = "IgntrBaD",
		[-2] = "Glow Bad",
		[-1] = "Unknown",
		[0] = "Trim Low",
		[1] = "User Off",
		[2] = "Stop",
		[3] = "Cooling",
		[4] = "Ready",
		[5] = "SetIdle!",
		[6] = "StickLo!",
		[7] = "GlowTest",
		[8] = "Starting",
		[9] = "BurnerOn",
		[10] = "Start On",
		[11] = "Ignition",
		[12] = "Pre Heat",
		[13] = "SwitchOver",
		[14] = "FuelRamp",
		[20] = "Run-Idle",
		[21] = "Running",
		[22] = "Run-Max",
		[23] = "ReStart",
	}
	local msg_table_JetCentral = {
		  [-21] = "ERROR",
		  [-20] = "- no data -",
		  [-19] = "MaxPump",
		  [-18] = "RPMSensorErr",
		  [-17] = "LowRPM",
		  [-16] = "MaxAmpers",
		  [-15] = "MaxTemp",
		  [-14] = "ComTurbErr",
		  [-13] = "TempSensErr",
		  [-12] = "RxSetupError",
		  [-11] = "Failsafe",
		  [-10] = "NoRx",
		  [-9] = "LowECUBatt",
		  [-8] = "LowRXBatt",
		  [-7] = "IgniterBad",
		  [-6] = "AcelerateBad",
		  [-5] = "ToIdle Error",
		  [-4] = "StarterError",
		  [-3] = "SwitchOverErr",
		  [-2] = "PreheatError",
		  [-1] = "IgnitionError",
		   [0] = "OFF",
		   [1] = "ManCooling",
	 	   [2] = "AutoCooling",
		   [6] = "GlowTest",
		   [7] = "StarterTest",
		   [8] = "PrimeFuel",
		   [9] = "PrimeBurner",
		  [10] = "Standby",
		  [11] = "Start",
		  [12] = "IgniterHeat",
		  [13] = "Ignition",
		  [14] = "Preheat",
		  [15] = "Switchover",
		  [16] = "To Idle",
		  [17] = "MinPumpOk",
		  [18] = "MaxPumpOk",
		  [19] = "Running",
		  [20] = "Full",
	}
	local msg_table_KOLOBRI_NG = {
		[-10] = "FLAME OUT",
		[-2] = "BATT LOW!",
		[-1] = "GLOW PLUG!",
		[0] = "OFF",
		[1] = "ON",
		[2] = "COOL-DOWN",
		[3] = "SLOW-DOWN",
		[10] = "STANDBY",
		[11] = "PROPIGNIT",
		[12] = "PROP-HEAT",
		[13] = "PUMPSTART",
		[14] = "FUELHEAT",
		[15] = "RAMP-UP",
		[20] = "AUTO",
	}
	local msg_table_Swiwin = {
		[-30] =  "no data",
		[-18] =  "Engine Offline",
		[-17] =  "Current overload",
		[-16] =  "Clutch failure",
		[-15] =  "Pump Temp High",
		[-14] =  "StarterTempHigh",
		[-13] =  "Lost Signal",
		[-12] =  "Fuel Valve Bad",
		[-11] =  "Gas Valve Bad",
		[-10] =  "TempSensorfail",
		 [-9] =  "Low Temp",
		 [-8] =  "High Temp",
		 [-7] =  "RPM Instability",
		 [-6] =  "RPM Low",
		 [-5] =  "Starter failure",
		 [-4] =  "Pump Anomaly",
		 [-3] =  "GlowPlug Bad",
		 [-2] =  "Low Battery",
		 [-1] =  "Time Out",
		  [0] =  "Stop",
		  [1] =  "Cooling",
		  [5] =  "TestGlowPlug",
		  [6] =  "TestFuelValve",
	      [7] =  "TestGasValve",
		  [8] =  "TestPump",
		  [9] =  "TestStarter",
		 [10] =  "Ready",
		 [11] =  "Ignition",
		 [12] =  "Preheat",
		 [13] =  "Fuelramp",
		 [20] =  "Running",
		 [21] =  "Restart",
	}
	local msg_table_Linton = {
		[-40] =  "-no data-",
		[-39] =  "Error Alarms",
		[-38] =  "Acc7",
		[-37] =  "Acc6",
		[-36] =  "Acc5",
		[-35] =  "Power limit",
		[-34] =  "Restart Fail",
		[-33] =  "Acc24",
		[-32] =  "Dec23",
		[-31] =  "Acc22",
		[-30] =  "Idle21",
		[-29] =  "Idle Time",
		[-28] =  "CTH Time",
		[-27] =  "Pump bubble",
		[-26] =  "Temp5 Pro",
		[-25] =  "Temp4 Pro",
		[-24] =  "Temp3 Pro",
		[-23] =  "Temp2 Pro",
		[-22] =  "Temp1 Pro",
		[-21] =  "HEGT3",
		[-20] =  "HEGT2",
		[-19] =  "HEGT1",
		[-18] =  "Fuel Fail",
		[-17] =  "RPM Low",
		[-16] =  "RPM Err",
		[-15] =  "Rc Lost Off",
		[-14] =  "Pump Fail",
		[-13] =  "PumpCurrent",
		[-12] =  "Pump Open",
		[-11] =  "CTH Fail",
		[-10] =  "MotorCurrent",
		[-9] =  "Motor Open",
		[-8] =  "IGT Short",
		[-7] =  "IGT Open",
		[-6] =  "EGT Warn",
		[-5] =  "TT Trans",
		[-4] =  "TT Open",
		[-3] =  "OverCurrent",
		[-2] =  "Volt High",
		[-1] =  "Volt Low",
		[0] =  "Ready",
		[1] =  "Ready start",
		[2] =  "Temp high",
		[3] =  "Start..",
		[4] =  "Burner..",
		[5] =  "Success",
		[6] =  "Heating1..",
		[7] =  "Heating2..",
		[8] =  "Heating3..",
		[9] =  "Heating4..",
		[10] =  "Heating5..",
		[11] =  "Heating6..",
		[12] =  "Pump Acc..",
		[13] =  "CTH..",
		[14] =  "Acc5..",
		[15] =  "Acc6..",
		[16] =  "Acc7..",
		[17] =  "Acc8..",
		[18] =  "Idling..",
		[19] =  "Acc..",
		[20] =  "Dec..",
		[21] =  "Speed..",
		[22] =  "Max Speed..",
		[23] =  "RC Learn",
		[24] =  "RC Learning..",
		[25] =  "RC Successful",
		[26] =  "Restart",
		[27] =  "Restart..",
		[28] =  "Cooling..",
		[29] =  "Error Status",
	}
  local status = getValue(src)
  if turb == 1 then
    status_str = msg_table_Jakadofsky[status] or tostring(Status)
  elseif turb == 2 then
    status_str = msg_table_evoJet[status] or tostring(Status)
  elseif turb == 3 then
    status_str = msg_table_PBS[status] or tostring(Status)
  elseif turb == 4 then
    status_str = msg_table_HORNET[status] or tostring(Status)
  elseif turb == 5 then
    status_str = msg_table_JetCat[status] or tostring(Status)
  elseif turb == 6 then
    status_str = msg_table_KingTech[status] or tostring(Status)
  elseif turb == 7 then
    status_str = msg_table_AMT[status] or tostring(Status)
  elseif turb == 8 then
    status_str = msg_table_Xicoy_Kolibri[status] or tostring(Status)
  elseif turb == 9 then
    status_str = msg_table_JetCentral[status] or tostring(Status)
  elseif turb == 10 then
    status_str = msg_table_KOLOBRI_NG[status] or tostring(Status)
  elseif turb == 11 then
    status_str = msg_table_Swiwin[status] or tostring(Status)
  elseif turb == 12 then
    status_str = msg_table_Linton[status] or tostring(Status)
  else
    status_str = ""
  end
	
	if turb == 5 then
		--JetCat
		lcd.drawText(x+60, y+8, "Status / OC", SMLSIZE)
	elseif turb == 9 then
		--JetJentral
		lcd.drawText(x+55, y+8, "Status / Alarm", SMLSIZE)
	elseif turb == 12 then
		--Linton
	elseif turb == 11 then
		--Swiwin
		lcd.drawText(x+55, y+8, "Status / Alarm", SMLSIZE)
	else
		lcd.drawText(x+50, y+3, "STATUS", MIDSIZE)
	end

	if turb == 5 then
		--JetCat
		lcd.drawText(x+25, y+31, status_str, MIDSIZE)
	elseif turb == 12 then
		--Linton
		lcd.drawText(x+15, y+31, status_str, MIDSIZE)
	elseif turb == 11 then
		--Swiwin
		lcd.drawText(x+15, y+31, status_str, MIDSIZE)
	elseif turb == 9 then
		--JetCentral
		lcd.drawText(x+25, y+31, status_str, MIDSIZE)
	elseif turb == 7 then
		--AMT
		lcd.drawText(x+5, y+31, status_str, MIDSIZE)
	elseif turb > 0 then
		if turb < 4 then
			--Jakadofsky, evoJet und PBS
			lcd.drawText(x+33, y+28, status_str, DBLSIZE)
		else
			if turb == 4 then
				--HORNET
				lcd.drawText(x+4, y+28, status_str, DBLSIZE)
			else
				--KingTech und Xicoy_Kolibri
				lcd.drawText(x+8, y+28, status_str, DBLSIZE)
			end
		end
	else
		lcd.drawText(x+20, y+28, status_str, DBLSIZE)
	end
end


function draw_rpm(x, y, src, zone)
  local rpm = getValue(src)/100
  lcd.drawBitmap(zone.ImgRpm, x+10, y+3, 100)
  lcd.drawText(x+60, y+3, "RPM", MIDSIZE)
  lcd.drawText(x+60, y+23, "x1000", SMLSIZE)
  lcd.drawNumber(x+115, y+40, rpm, RIGHT+PREC1+DBLSIZE)
end

function draw_fuel(x, y, src, zone)
  local fuel = getValue(src)
  lcd.drawBitmap(zone.ImgTnk, x+6, y+2, 250)
  lcd.drawText(x+80, y+3, "FUEL (ml)", MIDSIZE)
  lcd.drawNumber(x+200, y+40, fuel, RIGHT+DBLSIZE)
end

function draw_thrott_big(x, y, src)
	thrott = getValue(src)
  lcd.drawText(x+30, y+3, "Throttle", MIDSIZE)
  lcd.drawNumber(x+100, y+40, thrott, RIGHT+DBLSIZE)
  lcd.drawText(x+102, y+40, "%", DBLSIZE)
end


function draw_thrott_smal(x, y, src)
  local thrott = getValue(src)
  lcd.drawText(x+25, y+7, "Thrott.", 0)
  lcd.drawNumber(x+118, y+3, thrott, RIGHT+MIDSIZE)
  lcd.drawText(x+119, y+4, "%", MIDSIZE)
end

function draw_egt(x, y, src, zone)
  local egt = getValue(src)*10
  lcd.drawBitmap(zone.ImgEgt, x+12, y+15, 100)
  lcd.drawText(x+60, y+3, "EGT", MIDSIZE)
  lcd.drawNumber(x+117, y+28, egt, RIGHT+DBLSIZE)
end


function draw_battery(x, y, src, zone)
  local ecu_v = getValue(src)*10
  lcd.drawBitmap(zone.ImgBat, x+70, y+2, 100)
  lcd.drawNumber(x+168, y+4, ecu_v, RIGHT+PREC1+MIDSIZE)
  lcd.drawText(x+168, y+4, "V", MIDSIZE)
end

function draw_pump(x, y, src, turb)
  local pump = getValue(src)

  lcd.drawText(x+70, y+7, "Pump", 0)

  if turb == 6 or turb == 8 then
    --KingTech or Xicoy_Kolibri
    lcd.drawNumber(x+180, y+3, pump*100, RIGHT+MIDSIZE)
  else
    lcd.drawNumber(x+168, y+3, pump*10, RIGHT+PREC1+MIDSIZE)
    lcd.drawText(x+168, y+4, "V", MIDSIZE)
  end
end

function refresh(thisZone)
	lcd.setColor(CUSTOM_COLOR, WHITE)
	lcd.drawFilledRectangle(0, 0, 480, 145, CUSTOM_COLOR)

	draw_rpm(3, 0, thisZone.rpmIdx, thisZone)
	draw_fuel(123, 0, thisZone.fuelIdx, thisZone)
	draw_egt(0, 80, thisZone.egtIdx, thisZone)
	draw_status(123, 80, thisZone.statusIdx, thisZone.options.ECU_type)
	if not (thisZone.options.ECU_type == 10 ) then
		draw_battery(273, 80, thisZone.ecu_vIdx, thisZone)
	end
	draw_pump(273, 115, thisZone.pump_vIdx, thisZone.options.ECU_type)

	if thisZone.options.ECU_type == 5 then
		--JetCat
		local speed = getValue(thisZone.speedIdx)
		if speed < 1 then
			draw_thrott_big(325, 0, thisZone.throttIdx)
		else
			if speed < 2 then
				speed = 0
			end
			lcd.drawBitmap(thisZone.ImgSpd, 286, 68, 120)
			lcd.drawText(286, 90, "kmh", SMLSIZE)
			lcd.drawNumber(408, 70, speed, RIGHT+DBLSIZE)
			lcd.drawLine(273, 110, 479, 110, DOTTED, BLACK)
			lcd.drawLine(273, 111, 479, 111, DOTTED, BLACK)
			draw_thrott_smal(273, 111, thisZone.thrott)
		end
	elseif thisZone.options.ECU_type == 9 then
		--JetCentral
		local speed = getValue(thisZone.speedIdx)
		if speed < 1 then
			draw_thrott_big(325, 0, thisZone.throttIdx)
		else
			if speed < 2 then
				speed = 0
			end
			lcd.drawBitmap(thisZone.ImgSpd, 350, 68, 120)
			lcd.drawText(350, 90, "kmh", SMLSIZE)
			lcd.drawNumber(472, 70, speed, RIGHT+DBLSIZE)
			lcd.drawLine(337, 110, 479, 110, DOTTED, BLACK)
			lcd.drawLine(337, 111, 479, 111, DOTTED, BLACK)
			draw_thrott_smal(337, 111, thisZone.thrott)
		end
	else
		draw_thrott_big(325, 0, thisZone.throttIdx)
	end

	--lcd.drawLine(0, 0, 479, 0, SOLID, BLACK)
	--lcd.drawLine(0, 63, 479, 63, SOLID, BLACK)
	--lcd.drawFilledRectangle(0, 0, 480, 18)

	lcd.drawLine(0, 145, 479, 145, SOLID, BLACK)
	lcd.drawLine(0, 146, 479, 146, SOLID, BLACK)
	lcd.drawFilledRectangle(0, 146, 480, 128)

	lcd.drawLine(0, 79, 479, 79, DOTTED, BLACK)
	lcd.drawLine(0, 80, 479, 80, DOTTED, BLACK)
	lcd.drawLine(122, 0, 122, 144, DOTTED, BLACK)
	lcd.drawLine(123, 0, 123, 144, DOTTED, BLACK)
	if thisZone.options.ECU_type == 10 then
		lcd.drawLine(336, 0, 336, 144, DOTTED, BLACK)
		lcd.drawLine(337, 0, 337, 144, DOTTED, BLACK)
	else
		lcd.drawLine(336, 0, 336, 144, DOTTED, BLACK)
		lcd.drawLine(337, 0, 337, 144, DOTTED, BLACK)
		lcd.drawLine(337, 114, 479, 114, DOTTED, BLACK)
		lcd.drawLine(337, 115, 479, 115, DOTTED, BLACK)
	end

	if thisZone.options.ECU_type > 0 then
		if thisZone.options.ECU_type < 13 then
			lcd.drawBitmap(thisZone.ImgVsp, 320, 153, 100)
		end
	end

	lcd.setColor(CUSTOM_COLOR, WHITE)
	if thisZone.options.ECU_type == 1 then
		lcd.drawText(20, 158, "Jakadofsky", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 2 then
		lcd.drawText(20, 158, "evoJet", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 3 then
		lcd.drawText(20, 158, "PBS", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 4 then
		lcd.drawText(20, 158, "HORNET", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 5 then
		lcd.drawText(20, 158, "JetCat", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 6 then
		lcd.drawText(20, 158, "KingTech", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 7 then
		lcd.drawText(20, 158, "AMT", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 8 then
		lcd.drawText(20, 158, "Xicoy/Kolibiri", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 9 then
		lcd.drawText(20, 158, "JetCentral", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 10 then
		lcd.drawText(20, 158, "Kolibri-NG", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 11 then
		lcd.drawText(20, 158, "Swiwin", DBLSIZE + CUSTOM_COLOR)
	elseif thisZone.options.ECU_type == 12 then
		lcd.drawText(20, 158, "Linton", DBLSIZE + CUSTOM_COLOR)
	else
		lcd.setColor(CUSTOM_COLOR, RED)
		lcd.drawText(20, 158, "ECU  type  not  selected !", DBLSIZE + CUSTOM_COLOR)
	end
end

local function backgroundProcessWidget(widgetToProcessInBackground)
	-- Nichts
end
return { name="VSpeak ECU", options=defaultOptions, create=create, update=update, refresh=refresh, background=backgroundProcessWidget }
